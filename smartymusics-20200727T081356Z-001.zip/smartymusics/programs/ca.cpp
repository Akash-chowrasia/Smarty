#include<iostream>
using namespace std;
int main()
{
    cout<<"akash viva";
    return 0;
}
