print("ram manohar")
