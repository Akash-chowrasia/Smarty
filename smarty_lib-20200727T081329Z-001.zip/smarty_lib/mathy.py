from libs.ColorPython import Color
import os
responces=["--WELCOME TO YOUR PERSONAL ASSISTANT--","My name is SMARTY",Color.bold['blue'] + "Thanks\n bye,see you later...." + Color.reset,Color.bold['red'] + "sorry, This question is beyond my scope" + Color.reset, Color.bold['cyan'] + "Hii... how can i help you" + Color.reset, Color.bold['purple'] + "As i am your personal assistant,i born when you installed me in your system" + Color.reset]
def extract_numbers_from_text(text):
    l=[]
    for t in text.split(' '):
        try:
            l.append(int(t))
        except ValueError:
            pass
    return(l)
def lcm(l):
    a,b=l
    L=a if a>b else b
    while L<=a*b:
        if L%a==0 and L%b==0:
            print( Color.bold['purple'] + "LCM=" + Color.reset, L)
            return
        L+=1
def hcf(l):
    a,b=l
    H=a if a<b else b
    while H>=1:
        if a%H==0 and b%H==0:
            print( Color.bold['purple'] + "HCF=" + Color.reset, H)
            return
        H-=1
def add(a):
    print( Color.bold['purple'] + "SUM=" + Color.reset, sum(a))
def sub(l):
    a,b=l
    print( Color.bold['purple'] + "DIFFERENCE=" + Color.reset, b-a)
def multiply(a):
    b=1
    for i in a:
        b*=i
    print( Color.bold['purple'] + "RESULT=" + Color.reset, b)
def division(l):
    a,b=l
    print( Color.bold['purple'] + "RESULT=" + Color.reset, a/b)
def end():
    print(responces[2])
    exit()
def myname():
    print(responces[1])
def sorry():
    print(responces[3])
def wish():
    print(responces[4])
def age():
    print(responces[5])
def help():
    print( Color.bold['yellow'] + "@" * os.get_terminal_size()[0] + Color.reset )
    print( Color.bold['green'] + "(1)Calculations" + Color.reset)
    print( Color.bold['red'] + "DESCRIPTION:" + Color.reset)
    print("I can perform any operation without using any operator.")
    print( Color.bold['cyan'] + "EXAMPLE:" + Color.reset)
    print("(a)ADDITION:add 2 and 3\n(b)SUBTRACTION:subtract 4 and 3\n(c)MULTIPLICATION:multiply 3 and 4\n(d)DIVISION:divide 10 by 2 \n(e)LCM:lcm of 5 and 10\n(f)HCF:hcf of 5 and 10")
    print("I can provide you information about calendar.")     
    print( Color.bold['cyan'] + "EXAMPLE:" + Color.reset)
    print("please show the calendar of may 2019")
    print( Color.bold['purple'] + "="*os.get_terminal_size()[0]  + Color.reset)
    print( Color.bold['green'] + "(3)Time" + Color.reset)
    print( Color.bold['red'] + "DESCRIPTION:" + Color.reset)
    print("You can find here current time.")
    print( Color.bold['cyan'] + "EXAMPLE:" + Color.reset)
    print("current time please")
    print( Color.bold['purple'] + "="*os.get_terminal_size()[0]  + Color.reset)
    print( Color.bold['green'] + "(4)Date" + Color.reset)
    print( Color.bold['red'] + "DESCRIPTION:" + Color.reset)
    print("You can find here current date.")
    print( Color.bold['cyan'] + "EXAMPLE:" + Color.reset)
    print("\nshow the current date")
    print( Color.bold['purple'] + "="*os.get_terminal_size()[0]  + Color.reset)
    print( Color.bold['green'] + "(5)Status" + Color.reset)
    print( Color.bold['red'] + "DESCRIPTION:" + Color.reset)
    print("From this command you can find a shorthand status of this system.")
    print( Color.bold['cyan'] + "EXAMPLE:" + Color.reset)
    print("please show the status of the system")
    print( Color.bold['purple'] + "="*os.get_terminal_size()[0]  + Color.reset)
    print( Color.bold['green'] + "(6)Poweroff And Restart" + Color.reset)
    print( Color.bold['red'] + "DESCRIPTION:" + Color.reset)
    print("This command can help you to turn off as well as restart the system.")
    print( Color.bold['cyan'] + "EXAMPLE:" + Color.reset)
    print("(a)POWEROFF:poweroff the system\n(b)RESTART:reboot the system    ")
    print( Color.bold['purple'] + "="*os.get_terminal_size()[0]  + Color.reset)
    print( Color.bold['green'] + "(7)Path" + Color.reset)
    print( Color.bold['red'] + "DESCRIPTION:" + Color.reset)
    print("From here you can know current and system path.")
    print( Color.bold['cyan'] + "EXAMPLE:" + Color.reset)
    print("(a)CURRENT PATH:please show the current path\n(b)SYSTEM PATH:please provide the system path")
    print( Color.bold['purple'] + "="*os.get_terminal_size()[0]  + Color.reset)
    print( Color.bold['green'] + "(8)Lists" + Color.reset)
    print( Color.bold['red'] + "DESCRIPTION:" + Color.reset)
    print("This command help you to find list of musics,videos,pictures,pdf as well as recorded videos.")
    print( Color.bold['cyan'] + "EXAMPLE:" + Color.reset)
    print("(a)MUSICS:give me list of music\n(b)VIDEOS:provide me the list of videos\n(c)LOGS:please show the list of video logs\n(d)PICS:please show the list of pics\n(e)PDF:please show the list of pdf")
    print( Color.bold['purple'] + "="*os.get_terminal_size()[0]  + Color.reset)
    print( Color.bold['green'] + "(9)Play" + Color.reset)
    print( Color.bold['red'] + "DESCRIPTION:" + Color.reset)
    print("From here you can play anything like musics,videos,recorded videos")
    print( Color.bold['cyan'] + "EXAMPLE:" + Color.reset)
    print("(a)MUSICS:smarty play a music for me\n(b)VIDEOS:play a video for me\n(c)please play a video log")
    print( Color.bold['purple'] + "="*os.get_terminal_size()[0]  + Color.reset)
    print( Color.bold['green'] + "(10)Downloading" + Color.reset)
    print( Color.bold['red'] + "DESCRIPTION:" + Color.reset)
    print("I provide you the feature of downloading videos as well as pdf.")
    print( Color.bold['cyan'] + "EXAMPLE:" + Color.reset)
    print("(a)VIDEO DOWNLOAD:download a video of mychoice\n(b)PDF DOWNLOAD:download a pdf for me")
    print( Color.bold['purple'] + "="*os.get_terminal_size()[0]  + Color.reset)
    print( Color.bold['green'] + "(11)Open Any File" + Color.reset)
    print( Color.bold['red'] + "DESCRIPTION:" + Color.reset)
    print("This command will make you open any types of file with any type of extension like .pdf,.cpp etc.")
    print( Color.bold['cyan'] + "EXAMPLE:" + Color.reset)
    print("open a particular file for me")
    print( Color.bold['purple'] + "="*os.get_terminal_size()[0]  + Color.reset)
    print( Color.bold['green'] + "(12)Google Search" + Color.reset)
    print( Color.bold['red'] + "DESCRIPTION:" + Color.reset)
    print("From this you can search Google.")
    print( Color.bold['cyan'] + "EXAMPLE:" + Color.reset)
    print("please make a google search for me")
    print( Color.bold['purple'] + "="*os.get_terminal_size()[0]  + Color.reset)
    print( Color.bold['green'] + "(13)Run Any Program" + Color.reset)
    print( Color.bold['red'] + "DESCRIPTION:" + Color.reset)
    print("From this command you will be able to run any file with anytypes of extensions.")
    print( Color.bold['cyan'] + "EXAMPLE:" + Color.reset)
    print("run a particular program for me")
    print( Color.bold['purple'] + "="*os.get_terminal_size()[0]  + Color.reset)
    print( Color.bold['green'] + "(14)Create a program" + Color.reset)
    print( Color.bold['red'] + "DESCRIPTION:" + Color.reset)
    print("This command will help you to create a new program for you.")
    print( Color.bold['cyan'] + "EXAMPLE:" + Color.reset)
    print("create a program for me")
    print( Color.bold['purple'] + "="*os.get_terminal_size()[0]  + Color.reset)
    print( Color.bold['green'] + "(15)Using Webcam" + Color.reset)
    print( Color.bold['red'] + "DESCRIPTION:" + Color.reset)
    print("This command provides features of capturing pictures and record videos from camcoder.")
    print( Color.bold['cyan'] + "EXAMPLE:" + Color.reset)
    print("(a)PIC:take a picture\n(b)VIDEO:make a video log for me")
    print( Color.bold['purple'] + "="*os.get_terminal_size()[0]  + Color.reset)
    print( Color.bold['green'] + "(16)End The Program" + Color.reset)
    print( Color.bold['red'] + "DESCRIPTION:" + Color.reset)
    print("This command will end this program.")
    print( Color.bold['cyan'] + "EXAMPLE:" + Color.reset)
    print("please end this program")
    print( Color.bold['purple'] + "="*os.get_terminal_size()[0]  + Color.reset)
    print( Color.bold['green'] + "(17)History" + Color.reset)
    print( Color.bold['red'] + "DESCRIPTION:" + Color.reset)
    print("From this you can find all previous searches made to this program.")
    print( Color.bold['cyan'] + "EXAMPLE:" + Color.reset)
    print("provide me command history")





operations={"ADD":add,"PLUS":add,"ADDITION":add,"SUM":add,"MINUS":sub,"SUBTRACTION":sub,"SUBTRACT":sub,"PRODUCT":multiply,"MULTIPLICATION":multiply,"MULTIPLY":multiply,"DIVIDE":division,"DIVISION":division,"LCM":lcm,"HCF":hcf}
commands={"NAME":myname,"END":end,"EXIT":end,"CLOSE":end,"HELLO":wish,"AGE":age,"HELP":help}
