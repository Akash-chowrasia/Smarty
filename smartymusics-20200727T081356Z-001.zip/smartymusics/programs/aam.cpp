#include<iostream>
using namespace std;
int main()
{
    int a;
    cout<<"enter a number";
    cin>>a;
    cout<<"the number is "<<a;
}
