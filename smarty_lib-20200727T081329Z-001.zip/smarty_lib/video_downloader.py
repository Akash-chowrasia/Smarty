import urllib.parse
import re
import urllib.request
import webbrowser
import os
new=2
a=input("enter to search:")
query_string = urllib.parse.urlencode({"search_query" : {a}})
html_content = urllib.request.urlopen("http://www.youtube.com/results?" + query_string)
search_results = re.findall(r'href=\"\/watch\?v=(.{11})', html_content.read().decode())
play="http://www.youtube.com/watch?v=" + search_results[0]
os.system("youtube-dl %s"%play)

